package com.ras.nvda_stock.stock;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "nvidia_stats")
public class Stock {
    private 
}
