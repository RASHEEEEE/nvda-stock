package com.ras.user_login_master;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLoginMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
