package com.ras.user_login_master.repository;


import com.ras.user_login_master.model.EmailConfirmationToken;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface EmailConfirmationTokenRepository extends JpaRepository<EmailConfirmationToken, String>{
    EmailConfirmationToken findByToken(String token);
}
