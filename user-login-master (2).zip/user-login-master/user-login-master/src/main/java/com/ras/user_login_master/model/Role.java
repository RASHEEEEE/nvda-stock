package com.ras.user_login_master.model;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collation = "roles")
@Data
public class Role {
    @Id
    private String id;
    private ERole role;

}
