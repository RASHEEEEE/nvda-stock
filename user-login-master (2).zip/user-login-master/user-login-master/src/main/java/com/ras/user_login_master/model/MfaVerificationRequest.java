package com.ras.user_login_master.model;
import lombok.Data;

@Data
public class MfaVerificationRequest {
    private String username;
    private String totp;
}
