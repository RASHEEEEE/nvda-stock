package com.ras.user_login_master;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserLoginMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserLoginMasterApplication.class, args);
	}

}
