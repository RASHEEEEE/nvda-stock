package com.ras.user_login_master.service;

import dev.samstevens.totp.exceptions.QrGenerationException;

public interface TOTPService {

    String generateSecretKey();
    String getQRCode(final String secret) throws QrGenerationException;
    boolean verifyTotp(final String code, final String secret);
}
