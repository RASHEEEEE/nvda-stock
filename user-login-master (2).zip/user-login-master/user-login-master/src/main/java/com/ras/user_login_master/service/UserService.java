package com.ras.user_login_master.service;

import com.ras.user_login_master.model.User;
import com.ras.user_login_master.exception.InvalidTokenException;
import com.ras.user_login_master.exception.UserAlreadyExistException;
import com.ras.user_login_master.model.MfaTokenData;
import dev.samstevens.totp.exceptions.QrGenerationException;
import jakarta.mail.MessagingException;
import java.util.Optional;
public interface UserService {
    MfaTokenData registerUser(User user) throws UserAlreadyExistException, QrGenerationException;
    //MfaTokenData mfaSetup(String email) throws UnkownIdentifierException, QrGenerationException;
    boolean verifyTotp(final String code,String username);

    void sendRegistrationConfirmationEmail(final User user) throws MessagingException;
    boolean verifyUser(final String token) throws InvalidTokenException;
}
