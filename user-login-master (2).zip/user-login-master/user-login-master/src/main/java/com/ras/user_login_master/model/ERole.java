package com.ras.user_login_master.model;

public enum ERole {
    USER,
    ADMIN
}
