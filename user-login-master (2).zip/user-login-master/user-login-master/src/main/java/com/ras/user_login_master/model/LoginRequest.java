package com.ras.user_login_master.model;
import lombok.Data;

@Data
public class LoginRequest {
    String username;
    String password;
}
